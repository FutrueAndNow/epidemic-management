<?php


namespace app\index\model;


use think\Model;

class tripreportinfo extends Model
{

}