<?php


namespace app\index\model;


use think\Model;

class leaveschoolinfo extends Model
{

}