<?php


namespace app\index\model;


use think\Model;

class epknowledgeinfo extends Model
{

}