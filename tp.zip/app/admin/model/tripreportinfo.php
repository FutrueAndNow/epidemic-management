<?php


namespace app\admin\model;


use think\Model;

class tripreportinfo extends Model
{

}