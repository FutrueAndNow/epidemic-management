<?php


namespace app\admin\controller;


class Index
{
    public function index()
    {

         return 11;
    }
}