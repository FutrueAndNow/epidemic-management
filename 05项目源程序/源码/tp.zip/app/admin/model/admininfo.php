<?php

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class admininfo extends Model
{
    //
}
